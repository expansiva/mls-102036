declare module "_102036_/l2/collabMessagesIndexedDB.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102036_/l2/shared/interfacesFrontend" {
    export type IAgentMeta = {
        visibility: 'public' | 'private';
        agentName: string;
        agentProject?: number;
        agentFolder?: string;
        scope?: string[];
        avatar_url?: string;
        agentDescription: string;
    };
    export interface IOpenClawAgent {
        id: string;
        name: string;
        avatarUrl: string;
        collabUserId: string;
        createdAt: string;
    }
    export interface IOpenClawIntegration {
        id: string;
        name: string;
        url: string;
        connectorId: string;
        bearerToken: string;
        agents: IOpenClawAgent[];
        createdAt: string;
    }
    export interface ToolsBeforeSendMessage {
        toolName: string;
        args: Record<string, any>;
    }
}
declare module "_102036_/l2/shared/interfaces" {
    export enum HttpStatus {
        OK = 200,
        NOT_MODIFIED = 304,
        BAD_REQUEST = 400,
        UNAUTHORIZED = 401,
        NOT_FOUND = 404,
        FORBIDDEN = 403,
        CONFLICT = 409,
        SERVER_ERROR = 500,
        UNPROCESSABLE_ENTITY = 422,
        NOT_IMPLEMENTED = 501,
        SERVICE_UNAVAILABLE = 503
    }
    export interface RequestBase {
        action: string;
    }
    export interface ResponseBase {
        statusCode: HttpStatus;
        msg?: string;
    }
    export interface RequestAddMessage extends RequestBase {
        action: "addMessage";
        userId: string;
        threadId: string;
        content: string;
        contextToBot?: Record<string, any>;
        replyTo?: string;
        senderDeviceId?: string;
    }
    export interface ResponseAddMessage extends ResponseBase {
        message: Message;
        messages?: Message[];
        task?: TaskData;
        taskRoomThread?: Thread;
        botOutputs?: BotOutput[];
        integrationOutputs?: IntegrationOutput[];
    }
    export interface RequestCreateAttachmentUpload extends RequestBase {
        action: "createAttachmentUpload";
        userId: string;
        threadId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface ResponseCreateAttachmentUpload extends ResponseBase {
        attachmentId: string;
        storageKey: string;
        uploadUrl: string;
        headers: Record<string, string>;
        expiresAt: string;
    }
    export interface AttachmentUploadCompletion {
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
    }
    export interface RequestCompleteAttachmentUpload extends RequestBase {
        action: "completeAttachmentUpload";
        userId: string;
        threadId: string;
        content?: string;
        replyTo?: string;
        attachments: AttachmentUploadCompletion[];
    }
    export interface ResponseCompleteAttachmentUpload extends ResponseBase {
        message: Message;
    }
    export type AttachmentUploadFailureStage = 'storage_put';
    export type AttachmentUploadFailureKind = 'network' | 'http';
    export interface RequestReportAttachmentUploadFailure extends RequestBase {
        action: "reportAttachmentUploadFailure";
        userId: string;
        threadId: string;
        attachmentId: string;
        storageKey: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        stage: AttachmentUploadFailureStage;
        failure: AttachmentUploadFailureKind;
        httpStatus?: number;
        pageOrigin: string;
    }
    export interface ResponseReportAttachmentUploadFailure extends ResponseBase {
        logged: boolean;
    }
    export interface RequestDeleteAttachment extends RequestBase {
        action: "deleteAttachment";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseDeleteAttachment extends ResponseBase {
        message: Message;
    }
    export interface RequestGetAttachmentUrl extends RequestBase {
        action: "getAttachmentUrl";
        userId: string;
        threadId: string;
        messageId: string;
        attachmentId: string;
    }
    export interface ResponseGetAttachmentUrl extends ResponseBase {
        url: string;
        expiresAt: string;
    }
    export interface RequestUpdateMessage extends RequestBase {
        action: "updateMessage";
        userId: string;
        threadId: string;
        messageId: string;
        reaction?: string;
        pin?: boolean;
        favorite?: boolean;
        readConfirmation?: "request" | "confirm" | "cancel" | "requestExecution" | "reviewExecution";
        messageAction?: "delete" | "moderate" | "createTask";
        editContent?: string;
        taskTitle?: string;
    }
    export interface ResponseUpdateMessage extends ResponseBase {
        message: Message;
        thread?: Thread;
        messages?: Message[];
        user?: User;
        users?: User[];
    }
    export interface RequestAddMessageAI extends RequestBase {
        action: "addMessageAI";
        userId: string;
        threadId: string;
        taskTitle: string;
        userMessage: string;
        agentName: string;
        inputAI: IAMessageInputType[];
        longTermMemory?: Record<string, string>;
        replyTo?: string;
    }
    export interface ResponseAddMessageAI extends ResponseBase {
        message: Message;
        task: TaskData;
    }
    export interface RequestApplyIntents extends RequestBase {
        action: "applyIntents";
        userId: string;
        intents: AgentIntent[];
    }
    export interface ResponseApplyIntents extends ResponseBase {
        message?: Message;
        task: TaskData;
        moduleAdvance?: {
            commandId: string;
            outcome: 'applied' | 'unchanged';
        };
        moduleMessage?: {
            state: 'sent' | 'pending';
            threadId: string;
            orderAt?: string;
        };
    }
    export interface RequestAddUser extends RequestBase {
        action: "addUser";
        name: string;
        avatar_url?: string;
    }
    export interface ResponseAddUser extends ResponseBase {
        user: User;
    }
    export interface RequestAddOrUpdateOpenClawConnector extends RequestBase {
        action: "addOrUpdateOpenClawConnector";
        userId: string;
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs?: number;
        defaultOutputMode?: OpenClawOutputMode;
    }
    export interface ResponseAddOrUpdateOpenClawConnector extends ResponseBase {
        connector: OpenClawConnector;
    }
    export interface RequestRemoveOpenClawConnector extends RequestBase {
        action: "removeOpenClawConnector";
        userId: string;
        connectorId: string;
    }
    export interface ResponseRemoveOpenClawConnector extends ResponseBase {
        connectorId: string;
    }
    export interface RequestListOpenClawConnectors extends RequestBase {
        action: "listOpenClawConnectors";
        userId: string;
    }
    export interface ResponseListOpenClawConnectors extends ResponseBase {
        connectors: OpenClawConnector[];
    }
    export interface RequestListOpenClawAvailableAgents extends RequestBase {
        action: "listOpenClawAvailableAgents";
        userId: string;
        connectorId: string;
    }
    export interface ResponseListOpenClawAvailableAgents extends ResponseBase {
        connectorId: string;
        defaultId: string;
        mainKey: string;
        scope: "per-sender" | "global";
        agents: OpenClawRemoteAgentSummary[];
    }
    export interface RequestCreateOpenClawAgent extends RequestBase {
        action: "createOpenClawAgent";
        userId: string;
        connectorId: string;
        name: string;
        workspace: string;
        emoji?: string;
        avatar?: string;
        soulMd?: string;
        identityMd?: string;
    }
    export interface ResponseCreateOpenClawAgent extends ResponseBase {
        connectorId: string;
        agent: OpenClawRemoteAgentSummary;
        collabUserId: string;
    }
    export interface RequestDeleteOpenClawAgent extends RequestBase {
        action: "deleteOpenClawAgent";
        userId: string;
        connectorId: string;
        agentId: string;
        deleteFiles?: boolean;
    }
    export interface ResponseDeleteOpenClawAgent extends ResponseBase {
        connectorId: string;
        agentId: string;
        collabUserId?: string;
        updatedThreadIds: string[];
    }
    export interface RequestUpdateUserDetails extends RequestBase {
        action: "updateUserDetails";
        userId: string;
        name?: string;
        status?: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        deviceId?: string;
        subscription?: PushSubscriptionData;
    }
    export interface ResponseUpdateUserDetails extends ResponseBase {
        user: User;
    }
    export interface RequestAddThread extends RequestBase {
        action: "addThread";
        userId: string;
        name: string;
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        languages: string[];
        avatar_url: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
    }
    export interface ResponseAddThread extends ResponseBase {
        thread: Thread;
    }
    export type HumanDmErrorCode = "not_found" | "self" | "schema" | "not_human" | "legacy_ambiguous" | "archived" | "pair_corrupt" | "storage_unavailable" | "contention_exhausted" | "unknown_outcome";
    export interface RequestEnsureHumanDm extends RequestBase {
        action: "ensureHumanDm";
        userId: string;
        recipientUserId: string;
        group: ThreadGroup;
    }
    export interface ResponseEnsureHumanDm extends ResponseBase {
        outcome?: "created" | "existing";
        thread?: Thread;
        code?: HumanDmErrorCode;
    }
    export interface RequestEnsureModuleThread extends RequestBase {
        action: 'ensureModuleThread';
        userId: string;
        email: string;
        project: string;
        module: string;
        name: string;
    }
    export interface ResponseEnsureModuleThread {
        userId: string;
        thread: Thread;
        created: boolean;
    }
    export interface RequestOpenModuleTask extends RequestBase {
        action: 'openModuleTask';
        ref: TaskModuleRef;
        plan: ModulePlan;
        startStep: string;
        origin: ModuleOrigin;
        owner: string | null;
        actorNow: string | null;
        title: string;
        room: ModuleRoomChoice;
        message?: {
            content: string;
        };
        executor: TaskModuleExecutor;
    }
    export interface ResponseOpenModuleTask {
        task: TaskData;
        room: Thread;
        created: boolean;
        moduleMessage?: {
            state: 'sent' | 'pending';
            threadId: string;
            orderAt?: string;
        };
    }
    export interface RequestGetModuleTask extends RequestBase {
        action: 'getModuleTask';
        ref: Omit<TaskModuleRef, 'workflowVersion'>;
    }
    export interface ResponseGetModuleTask {
        task: TaskData;
        room: Thread | null;
        roomIssue?: 'not_linked' | 'missing';
        messageId?: string;
    }
    export type ModuleActionError = {
        code: 'busy';
    } | {
        code: 'module_task_incomplete';
        taskId: string;
    } | {
        code: 'ambiguous';
    } | {
        code: 'link_conflict';
    } | {
        code: 'identity_too_large';
    };
    export interface RequestLinkModulePerson extends RequestBase {
        action: 'linkModulePerson';
        userId: string;
        mdmId: string;
        loginEmail: string;
    }
    export interface ResponseLinkModulePerson {
        cmUserId: string;
        outcome: 'linked' | 'existing';
    }
    export interface RequestResolveModulePeople extends RequestBase {
        action: 'resolveModulePeople';
        userId: string;
        mdmIds?: string[];
        cmUserIds?: string[];
    }
    export interface ResponseResolveModulePeople {
        people: {
            mdmId?: string;
            cmUserId?: string;
            state: 'linked' | 'unlinked' | 'removed' | 'inconsistent';
        }[];
    }
    export interface RequestListModuleTasks extends RequestBase {
        action: 'listModuleTasks';
        project: string;
        module: string;
        processId?: string;
        cursor?: string;
        pageSize: number;
    }
    export interface ResponseListModuleTasks {
        items: {
            ref: TaskModuleRef;
            taskId: string;
            revision: number;
            status: TaskStatus;
        }[];
        cursor?: string;
    }
    export interface RequestDeleteThread extends RequestBase {
        action: "deleteThread";
        userId: string;
        threadId: string;
    }
    export interface ResponseDeleteThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestUpdateThread extends RequestBase {
        action: "updateThread";
        userId: string;
        threadId: string;
        newOwnerId?: string;
        name?: string;
        visibility?: ThreadVisibility;
        status?: ThreadStatus;
        group?: ThreadGroup;
        languages?: string[];
        avatar_url?: string;
        defaultTopics?: string[];
        welcomeMessage?: string;
        notification?: ThreadNotification;
    }
    export interface ResponseUpdateThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetTaskUpdate extends RequestBase {
        action: "getTaskUpdate";
        userId: string;
        messageId: string;
        taskId: string;
    }
    export interface ResponseGetTaskUpdate extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddTaskAISteps extends RequestBase {
        action: "addTaskAISteps";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        stepdIdToChangeStatus: number | null;
        newStatus: AIStepStatus;
        traceMsg: string | null;
        newTaskTitle: string;
        steps: AIPayload[];
    }
    export interface ResponseAddTaskAISteps extends ResponseBase {
        task: TaskData;
    }
    /**
     * add new prompts to a existing interaction,
     * change status of stepIdToChangeStatus to newStatus
     * change status of interactionStepId to 'in_progress'
     * start LLM
     */
    export interface RequestAppendPromptToInteraction extends RequestBase {
        action: "appendPromptToInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        interactionStepId: number;
        inputAI: IAMessageInputType[];
        stepdIdToChangeStatus: number;
        newStatus: AIStepStatus;
        traceMsg?: string;
    }
    export interface ResponseAppendPromptToInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateStepStatus extends RequestBase {
        action: "updateStepStatus";
        userId: string;
        messageId: string;
        taskId: string;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        newTaskTitle?: string;
        newTaskStatus?: TaskStatus;
    }
    export interface ResponseUpdateStepStatus extends ResponseBase {
        task: TaskData;
        message?: Message;
    }
    export interface RequestAddTaskAIInteraction extends RequestBase {
        action: "addTaskAIInteraction";
        userId: string;
        messageId: string;
        taskId: string;
        parentStepId: number;
        inputAI: IAMessageInputType[];
    }
    export interface ResponseAddTaskAIInteraction extends ResponseBase {
        task: TaskData;
    }
    export interface RequestUpdateTaskTitle extends RequestBase {
        action: "updateTaskTitle";
        userId: string;
        messageId: string;
        taskId: string;
        newTitle: string;
    }
    export interface ResponseUpdateTaskTitle extends ResponseBase {
        task: TaskData;
    }
    export interface RequestEnsureTaskRoom extends RequestBase {
        action: "ensureTaskRoom";
        userId: string;
        taskId: string;
        parentThreadId?: string;
    }
    export interface ResponseEnsureTaskRoom extends ResponseBase {
        task: TaskData;
        thread: Thread;
    }
    export type UserMemorySectionName = 'identity_hints' | 'communication_style' | 'work_rhythm' | 'decision_style' | 'authority_hints' | 'learned_preferences';
    export interface UserMemorySourceInput {
        kind: 'message' | 'memory_section' | 'confirmation';
        ref: string;
    }
    export interface RequestGetUserMemory extends RequestBase {
        action: 'getUserMemory';
        userId: string;
        threadId: string;
        openSourceMessageId?: string;
    }
    export interface RequestProposeUserMemory extends RequestBase {
        action: 'proposeUserMemory';
        userId: string;
        threadId: string;
        expectedVersion: number;
        idempotencyKey: string;
        updates: Partial<Record<UserMemorySectionName, string>>;
        sources?: Partial<Record<UserMemorySectionName, UserMemorySourceInput[]>>;
        reason: string;
    }
    export interface RequestDecideUserMemoryProposal extends RequestBase {
        action: 'decideUserMemoryProposal';
        userId: string;
        threadId: string;
        proposalId: string;
        decision: 'confirm' | 'reject';
        expectedVersion: number;
        idempotencyKey: string;
        reviewMessageId?: string;
    }
    export interface RequestCorrectUserMemory extends RequestBase {
        action: 'correctUserMemory';
        userId: string;
        threadId: string;
        section: UserMemorySectionName;
        content: string;
        sources?: UserMemorySourceInput[];
        expectedVersion: number;
        idempotencyKey: string;
        reviewMessageId?: string;
    }
    export interface RequestInvalidateUserMemory extends RequestBase {
        action: 'invalidateUserMemory';
        userId: string;
        threadId: string;
        section: UserMemorySectionName | 'all';
        expectedVersion: number;
        idempotencyKey: string;
        reviewMessageId?: string;
    }
    export interface ResponseUserMemory extends ResponseBase {
        memory: unknown;
    }
    export interface RequestGetE01Execution extends RequestBase {
        action: 'getE01Execution';
        userId: string;
        threadId: string;
        executionId?: string;
        sourceMessageId?: string;
        openSourceMessageId?: string;
    }
    export interface RequestCancelE01Execution extends RequestBase {
        action: 'cancelE01Execution';
        userId: string;
        threadId: string;
        executionId: string;
    }
    export interface ResponseE01Execution extends ResponseBase {
        execution: unknown;
    }
    export interface RequestGetMessagesAfter extends RequestBase {
        action: "getMessagesAfter";
        threadId: string;
        lastOrderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesAfter extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessagesBefore extends RequestBase {
        action: "getMessagesBefore";
        threadId: string;
        orderAt: string;
        userId: string;
    }
    export interface ResponseGetMessagesBefore extends ResponseBase {
        data: Message[];
        hasMore: boolean;
    }
    export interface RequestGetMessage extends RequestBase {
        action: "getMessage";
        threadId: string;
        messageId: string;
        userId: string;
    }
    export interface ResponseGetMessage extends ResponseBase {
        message: Message;
    }
    export interface RequestAddUserInThread extends RequestBase {
        action: "addUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        auth: UserAuth;
    }
    export interface ResponseAddUserInThread extends ResponseBase {
        thread: Thread;
    }
    export interface RequestAddOrUpdateThreadOpenClawAgent extends RequestBase {
        action: "addOrUpdateThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface ResponseAddOrUpdateThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadOpenClawAgent extends RequestBase {
        action: "removeThreadOpenClawAgent";
        userId: string;
        threadId: string;
        alias: string;
    }
    export interface ResponseRemoveThreadOpenClawAgent extends ResponseBase {
        thread: Thread;
    }
    export interface RequestListThreadOpenClawAgents extends RequestBase {
        action: "listThreadOpenClawAgents";
        userId: string;
        threadId: string;
    }
    export interface ResponseListThreadOpenClawAgents extends ResponseBase {
        threadId: string;
        agents: OpenClawAgentBinding[];
    }
    export interface RequestRemoveUserInThread extends RequestBase {
        action: "removeUserInThread";
        userId: string;
        userIdOrName: string;
        threadId: string;
        eventVisibility?: "all" | "admin";
    }
    export interface ResponseRemoveUserInThread extends ResponseBase {
        thread: Thread;
        messages?: Message[];
    }
    export interface RequestGetThreadUpdate extends RequestBase {
        action: "getThreadUpdate";
        userId: string;
        threadId: string;
        deviceId?: string;
        lastOrderAt?: string;
        initialLoad?: boolean;
    }
    export interface ResponseGetThreadUpdate extends ResponseBase {
        thread: Thread;
        users: User[];
        messages?: Message[];
        threadsPending: string[];
        hasMore?: boolean;
        hasOlder?: boolean;
    }
    export interface RequestGetUserUpdate extends RequestBase {
        action: "getUserUpdate";
        userId?: string;
        name?: string;
        avatar_url?: string;
    }
    export interface RequestHeartbeat extends RequestBase {
        action: "heartbeat";
        userId: string;
        deviceId: string;
    }
    /** Activities of the caller. `userId` in the body is ignored; the person is the caller. */
    export interface RequestGetMyAssistantActivities extends RequestBase {
        action: "getMyAssistantActivities";
        cursor?: string;
        userId?: string;
    }
    /** One app or one of its modules that did not answer. */
    export type MyAssistantActivityPartial = {
        appId: string;
        moduleId: string;
        code: string;
    };
    export interface ResponseGetMyAssistantActivities extends ResponseBase {
        items: AssistantActivityItem[];
        partial: MyAssistantActivityPartial[];
        cursor?: string;
    }
    export interface ResponseHeartbeat extends ResponseBase {
        pending: string[];
        online: {
            users: number;
            devices: number;
        };
    }
    export interface ResponseGetUserUpdate extends ResponseBase {
        user: User;
    }
    export interface RequestGetUsers extends RequestBase {
        action: "getUsers";
        userId: string;
        status: "active" | "blocked";
        prefixName: string;
        callableOnly?: true;
    }
    export interface ResponseGetUsers extends ResponseBase {
        users: {
            userId: string;
            name: string;
            isAgent?: true;
            isHuman?: true;
            callable?: true;
        }[];
    }
    export interface RequestAppendLongTermMemory extends RequestBase {
        action: "appendLongTermMemory";
        userId: string;
        messageId: string;
        taskId: string;
        longTermMemory: Record<string, string>;
    }
    export interface ResponseAppendLongTermMemory extends ResponseBase {
        task: TaskData;
    }
    export interface RequestAddOrUpdateThreadBot extends RequestBase {
        action: "addOrUpdateThreadBot";
        userId: string;
        threadId: string;
        botId: string;
        llmPrompt: string;
        status: "active" | "disabled";
        config?: Record<string, any>;
    }
    export interface ResponseAddOrUpdateThreadBot extends ResponseBase {
        thread: Thread;
    }
    export interface BotFlexibleResultBase {
        ref?: string;
        output?: string;
        [key: string]: any;
    }
    export interface BotOutput {
        botId: string;
        cost: number;
        output: string;
    }
    export type IntegrationType = "openclaw";
    export interface ThreadIntegration {
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
        lastExecutionAt?: string;
    }
    export interface ThreadIntegrationConfig {
        url: string;
        bearerToken: string;
        inboundToken: string;
        agentId?: string;
        sessionId?: string;
    }
    export interface IntegrationOutput {
        integrationId: string;
        type: IntegrationType;
        responseMessageId?: string;
        responseMessage?: Message;
        error?: string;
    }
    export interface RequestAddOrUpdateThreadIntegration extends RequestBase {
        action: "addOrUpdateThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
        type: IntegrationType;
        status: "active" | "disabled";
        config: ThreadIntegrationConfig;
        triggers: ThreadBotTrigger[];
    }
    export interface ResponseAddOrUpdateThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestRemoveThreadIntegration extends RequestBase {
        action: "removeThreadIntegration";
        userId: string;
        threadId: string;
        integrationId: string;
    }
    export interface ResponseRemoveThreadIntegration extends ResponseBase {
        thread: Thread;
    }
    export interface RequestWebhookInbound {
        threadId: string;
        integrationId?: string;
        connectorId?: string;
        agentId?: string;
        content: string;
        type?: Message['type'];
        replyTo?: string;
        externalCaseId?: string;
        channel?: string;
        customerIdentity?: string;
        priority?: "low" | "normal" | "high" | "urgent";
        metadata?: Record<string, any>;
    }
    export interface ResponseWebhookInbound extends ResponseBase {
        message: Message;
    }
    export interface User {
        userId: string;
        name: string;
        status: "active" | "blocked" | "deleted";
        avatar_url?: string;
        md?: string;
        threads: string[];
        notifications?: UserNotifications[];
        favorites?: string[];
        readConfirmations?: UserReadConfirmations;
        kind?: UserKind;
        metadata?: UserMetadata;
        sub?: string;
        email?: string;
    }
    export interface UserReadConfirmations {
        pending?: string[];
        requested?: string[];
    }
    export interface PushSubscriptionData {
        endpoint: string;
        keys: {
            p256dh: string;
            auth: string;
        };
        expirationTime?: number | null;
    }
    export interface UserNotifications {
        deviceId: string;
        subscription: PushSubscriptionData;
    }
    export type UserKind = "human" | "synthetic_agent" | "pma";
    export interface UserMetadata {
        source?: "collab" | "openclaw" | "external";
        agentType?: "pma" | "agent" | "external_agent" | "module";
        definitionRef?: string;
        definitionVersion?: string;
        modelType?: string;
        connectorId?: string;
        agentId?: string;
        [key: string]: any;
    }
    export interface UserPerformanceCache extends User {
        lastSync?: string;
    }
    export type UserAuth = "admin" | "moderator" | "read" | "write" | "none";
    export interface ThreadUsers {
        userId: string;
        auth: UserAuth;
        notification?: ThreadNotification;
    }
    export type ThreadGroup = "CRM" | "TASK" | "DOCS" | "CONNECT" | "APPS" | "MOMENTS";
    export type ThreadVisibility = "public" | "private" | "company" | "team";
    export type ThreadStatus = "active" | "archived" | "deleting" | "deleted";
    export type ThreadNotification = "all" | "mentions" | "never";
    export interface Thread {
        threadId: string;
        name: string;
        users: ThreadUsers[];
        visibility: ThreadVisibility;
        status: ThreadStatus;
        group: ThreadGroup;
        history: ThreadHistoryEntry[];
        languages: string[];
        defaultTopics?: string[];
        welcomeMessage?: string;
        avatar_url: string;
        bots?: ThreadBot[];
        integrations?: ThreadIntegration[];
        openClawAgents?: OpenClawAgentBinding[];
        agentDm?: AgentDirectMessageBinding;
        personalMemoryProtection?: {
            kind: 'e01-personal-dm';
            ownerUserId: string;
            agentUserId: string;
            protectedAt: string;
        };
        pinnedMessages?: PinnedMessage[];
        kind?: 'thread' | 'task-room';
        taskRoom?: {
            taskId: string;
            parentThreadId: string;
            workflowType: WorkflowType;
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
        archivedAt?: string;
        archivedBy?: string;
        deletedAt?: string;
        createdAt: string;
    }
    export interface MomentsPublisher {
        userId: string;
        name: string;
        avatar_url: string;
    }
    export interface MomentsFeedItem {
        threadId: string;
        publisher: MomentsPublisher;
        message: Message;
        seen: boolean;
        reach?: number;
    }
    export interface MomentsSeenItem {
        threadId: string;
        messageId: string;
    }
    export interface MomentsSubscriptionItem {
        threadId: string;
        publisher: MomentsPublisher;
        muted: boolean;
    }
    export interface MomentsStatsPost {
        messageId: string;
        createAt: string;
        preview: string;
        reach: number;
        reactions: number;
    }
    export interface RequestEnsureMomentsRoom extends RequestBase {
        action: "ensureMomentsRoom";
        userId: string;
    }
    export type MomentsAudience = 'all' | 'selected';
    export interface ResponseEnsureMomentsRoom extends ResponseBase {
        thread: Thread;
        audience: MomentsAudience;
    }
    export interface RequestSetMomentsAudience extends RequestBase {
        action: "setMomentsAudience";
        userId: string;
        audience: MomentsAudience;
    }
    export interface ResponseSetMomentsAudience extends ResponseBase {
        thread: Thread;
        audience: MomentsAudience;
    }
    export interface RequestSetMomentsReaders extends RequestBase {
        action: "setMomentsReaders";
        userId: string;
        add?: string[];
        remove?: string[];
    }
    export interface ResponseSetMomentsReaders extends ResponseBase {
        thread: Thread;
    }
    export interface RequestGetMomentsFeed extends RequestBase {
        action: "getMomentsFeed";
        userId: string;
        limit?: number;
        before?: string;
    }
    export interface ResponseGetMomentsFeed extends ResponseBase {
        items: MomentsFeedItem[];
    }
    export interface RequestMarkMomentSeen extends RequestBase {
        action: "markMomentSeen";
        userId: string;
        items: MomentsSeenItem[];
    }
    export interface ResponseMarkMomentSeen extends ResponseBase {
        ok: true;
    }
    export interface RequestSetMomentsMute extends RequestBase {
        action: "setMomentsMute";
        userId: string;
        threadId: string;
        muted: boolean;
    }
    export interface ResponseSetMomentsMute extends ResponseBase {
        ok: true;
    }
    export interface RequestGetMomentsSubscriptions extends RequestBase {
        action: "getMomentsSubscriptions";
        userId: string;
    }
    export interface ResponseGetMomentsSubscriptions extends ResponseBase {
        items: MomentsSubscriptionItem[];
    }
    export interface RequestGetMomentsStats extends RequestBase {
        action: "getMomentsStats";
        userId: string;
        limit?: number;
    }
    export interface ResponseGetMomentsStats extends ResponseBase {
        audience: number;
        posts: MomentsStatsPost[];
    }
    export interface PinnedMessage {
        messageId: string;
        pinnedBy: string;
        pinnedAt: string;
        excerpt?: string;
    }
    export interface AgentDirectMessageBinding {
        enabled: boolean;
        agentId: string;
        agentUserId: string;
        agentType: "pma" | "agent";
        status: "active" | "paused" | "disabled";
        configRef?: string;
    }
    export interface ThreadHistoryEntry {
        action: string;
        userId: string;
        timestamp: string;
    }
    export interface ThreadBot {
        botId: string;
        llmPrompt: string;
        threadFeature: ThreadFeature;
        threadPermissionLevel: ThreadPermissionLevel;
        triggers: ThreadBotTrigger[];
        status: "idle" | "running" | "disabled";
        lastExecutionAt?: string;
        memoryRef?: string;
        config?: Record<string, any>;
    }
    export type OpenClawOutputMode = "final_only" | "status_and_final";
    export type OpenClawSessionMode = "thread" | "thread_user";
    export type OpenClawHandoffThreadRole = "handoff" | "collaboration";
    export interface OpenClawConnector {
        connectorId: string;
        name: string;
        baseUrl: string;
        gatewayToken: string;
        inboundToken: string;
        enabled: boolean;
        defaultTimeoutMs: number;
        defaultOutputMode: OpenClawOutputMode;
        protocolVersion?: number;
        transport?: "ws" | "http";
    }
    export interface OpenClawAgentBinding {
        alias: string;
        connectorId: string;
        agentId: string;
        collabUserId: string;
        enabled: boolean;
        sessionMode?: OpenClawSessionMode;
        handoffThreadRole?: OpenClawHandoffThreadRole;
        defaultForThread?: boolean;
    }
    export interface OpenClawRemoteAgentSummary {
        id: string;
        name?: string;
        identity?: {
            name?: string;
            theme?: string;
            emoji?: string;
            avatar?: string;
            avatarUrl?: string;
        };
        workspace?: string;
        model?: {
            primary?: string;
            fallbacks?: string[];
        };
    }
    export interface OpenClawDeviceState {
        deviceId: string;
        publicKey: string;
        privateKeyPem: string;
        publicKeyPem?: string;
        deviceToken?: string;
        authorizedAt?: string;
    }
    export enum ThreadFeature {
        Summary = "summary",
        CustomPlugin = "custom_plugin",
        Tasks = "tasks",
        Workflow = "workflow",
        Notifications = "notifications",
        Voting = "voting",
        Moderation = "moderation",
        Feedback = "feedback"
    }
    export type ThreadPermissionLevel = "all" | "members" | "admin";
    export interface ThreadBotTrigger {
        type: BotTriggerType;
        match?: "any" | "all";
        conditions?: BotTriggerCondition[];
        args?: BotTriggerArgs;
    }
    export enum BotTriggerType {
        OnNewMessage = "onNewMessage",
        OnMention = "onMention",
        OnTaskCompleted = "onTaskCompleted",
        Schedule = "schedule",
        Manual = "manual"
    }
    export interface BotTriggerCondition {
        type: "hasTag" | "mention" | "startsWith" | "contains";
        value: string;
    }
    export type BotTriggerArgs = {
        cron: string;
    } | {
        taskType: string;
    } | Record<string, any>;
    export interface ThreadPerformanceCache extends Thread {
        lastMessage?: string;
        lastMessageTime?: string;
        unreadCount?: number;
        lastSync?: string;
    }
    export interface Message {
        threadId: string;
        orderAt: string;
        createAt: string;
        updatedAt?: string;
        senderId: string;
        content: string;
        language_detected?: string;
        externalPlatform?: string;
        translations?: Record<string, string>;
        reactions?: Record<string, string[]>;
        readConfirmations?: MessageReadConfirmation[];
        attachments?: MessageAttachment[];
        moderation?: MessageModeration;
        edits?: MessageEditVersion[];
        editedAt?: string;
        editedBy?: string;
        type?: 'text' | 'image' | 'video' | 'audio' | 'document' | 'location' | 'contact';
        pin?: boolean;
        taskId?: string;
        stepId?: number;
        taskRoomRole?: 'conversation' | 'system' | 'agent' | 'workflow';
        taskTitle?: string;
        taskStatus?: TaskStatus;
        taskResults?: string[];
        taskResultsTranslated?: Record<string, string>;
        taskTitleTranslated?: Record<string, string>;
        visibility?: "admin";
        url?: string;
        replyTo?: string;
        /** Screen address for one Nora activity. Built by code from the task, never from the model text. */
        noraOpen?: {
            projectId: string;
            page: string;
            recordParam?: string;
            recordId?: string;
        };
        /** Yes/no for one Nora command. Written by code, never by the model text. */
        noraConfirm?: {
            expiresAt: string;
            answered?: boolean;
        };
    }
    export type MessageAttachmentKind = 'image' | 'video' | 'audio' | 'document' | 'file';
    export type MessageAttachmentStatus = 'active' | 'deleted';
    export interface MessageAttachment {
        attachmentId: string;
        fileName: string;
        contentType: string;
        sizeBytes: number;
        kind: MessageAttachmentKind;
        storageKey: string;
        uploadedBy: string;
        uploadedAt: string;
        status: MessageAttachmentStatus;
        deletedBy?: string;
        deletedAt?: string;
        url?: string;
    }
    export interface MessageReadConfirmation {
        kind?: "read" | "execution";
        requestedBy: string;
        requestedAt: string;
        targetUserIds: string[];
        confirmedBy?: Record<string, string>;
        canceledAt?: string;
        canceledBy?: string;
        followupHistory?: MessageFollowupHistoryEntry[];
    }
    export interface MessageFollowupHistoryEntry {
        userId: string;
        reaction: string;
        at: string;
    }
    export type MessageModerationStatus = "deleted" | "moderated";
    export interface MessageModeration {
        status: MessageModerationStatus;
        by: string;
        at: string;
    }
    export interface MessageEditVersion {
        content: string;
        editedBy: string;
        editedAt: string;
    }
    export interface MessagePerformanceCache extends Message {
        lastSync?: string;
        status?: 'read' | 'unread' | 'edited';
        footers: {
            title?: string;
            lines: string[];
            icon?: string;
            color?: string;
            backgroundColor?: string;
            timestamp?: string;
        }[];
    }
    export type TaskOperationType = "create" | "read" | "update" | "delete" | "query";
    export interface TaskOperation {
        operation: TaskOperationType;
        taskId?: string;
        data?: Partial<TaskData>;
        filters?: Record<string, any>;
        message?: string | null;
    }
    export type TaskModuleRef = {
        project: string;
        module: string;
        entity: string;
        recordId: string;
        processId: string;
        workflowVersion: string | null;
    };
    export type ModuleOrigin = {
        kind: 'screen' | 'channel' | 'schedule' | 'event';
        by?: string;
        config?: string;
    };
    export type ModuleRoomChoice = {
        mode: 'exclusive' | 'person' | 'group';
        groupKey?: string;
        members?: string[];
    };
    export type ModuleStepKind = 'human' | 'mechanical' | 'llm' | 'wait' | 'alert';
    export type ModuleOwnerKind = 'person' | 'module' | 'agent' | 'clock';
    export type ModuleWake = {
        everyMinutes: number;
        until?: string;
        routine: string;
        nextAt: string;
        seq: number;
    };
    export type ModuleWakeEvent = {
        eventId: string;
        scheduledAt: string;
        attempt: number;
        ref: TaskModuleRef;
        taskId: string;
        stepKey: string;
        pass: number;
        seq: number;
        revision: number;
        routine: string;
        /** Absent or 'wake' is the wake tick. 'llm-step-finished' is the end of a module LLM step. */
        kind?: 'wake' | 'llm-step-finished';
        /** Present when kind is 'llm-step-finished': the requestModuleLlmStep commandId. */
        commandId?: string;
        /** Present when kind is 'llm-step-finished'. */
        state?: 'completed' | 'failed';
    };
    /** Refusal codes of requestModuleLlmStep. task_too_large matches module advance. */
    export type ModuleLlmStepErrorCode = 'paused' | 'llm_step_not_current' | 'llm_pass_limit' | 'task_too_large';
    export interface RequestModuleLlmStep extends RequestBase {
        action: 'requestModuleLlmStep';
        ref: TaskModuleRef;
        commandId: string;
        stepKey: string;
        /** Prompt messages already in the interaction shape (system and human). */
        input: IAMessageInputType[];
        /** Output schema in the interaction tool shape, when the caller sends one. */
        tools?: LLMTool[];
        maxPasses: number;
    }
    export interface ResponseModuleLlmStep {
        state: 'pending' | 'in_progress' | 'completed' | 'failed';
        /** Text, or the tool arguments, when state is completed. */
        result?: string;
        /** Present when state is failed. */
        failure?: {
            code: string;
            message: string;
        };
        cost?: number;
    }
    export type ModuleWakeReceipt = {
        eventId: string;
        outcome: 'accepted' | 'stale';
    };
    /** Person the cm asks the app about. Authorities stay raw; the app applies them. */
    export type AssistantOnBehalfOf = {
        cmUserId: string;
        authorities: string[];
        snapshotAt: string;
        via: 'nora';
    };
    /** A virtual employee that acts in its own name: its authority is the set of tools turned on for it; `requestedBy` is the user of the cm who called it, with no authority. */
    export type AssistantOnBehalfOfAgent = {
        agentId: string;
        requestedBy?: string;
        via: 'agent';
    };
    export type AssistantActivitiesRequest = {
        kind: 'activities';
        onBehalfOf: AssistantOnBehalfOf;
        includeNonActionable?: boolean;
        cursor?: string;
    };
    export type AssistantActivityPartial = {
        moduleId: string;
        code: string;
    };
    /** Step the app already returns inside an activity item. There is no page address on this object. */
    export type AssistantActivityStep = {
        stepKey?: string;
        title?: string;
        actorNow?: string | null;
        state?: string;
        actionable?: boolean;
    };
    /** Record identity the app already returns. `recordId` is the record value, not a page address. */
    export type AssistantActivityRef = {
        project?: string;
        module?: string;
        processId?: string;
        entity?: string;
        recordId?: string;
        workflowVersion?: string | null;
    };
    /** One projected activity. Extra fields from the app are kept; the cm does not interpret the module. */
    export type AssistantActivityItem = {
        projectId: string;
        moduleId: string;
        taskId: string;
        /** When the app last synced this projection. It is the only timestamp on the item. */
        syncedAt: string;
        taskTitle?: string;
        processTitle?: string;
        moduleTitle?: string;
        ref?: AssistantActivityRef;
        activity?: AssistantActivityStep;
        [key: string]: unknown;
    };
    export type AssistantActivitiesSuccess = {
        ok: true;
        outcome: 'done' | 'no_person';
        items: AssistantActivityItem[];
        cursor?: string;
        partial: AssistantActivityPartial[];
    };
    export type AssistantActivitiesFailure = {
        ok: false;
        outcome: 'unavailable' | 'config_error' | 'rejected' | 'invalid';
        status?: number;
        code?: string;
    };
    export type AssistantActivitiesResult = AssistantActivitiesSuccess | AssistantActivitiesFailure;
    /** Schema the app publishes. The cm checks it and does not invent module names. */
    export const ASSISTANT_CATALOG_SCHEMA = "assistant-catalog-v1";
    /** One action inside a module catalog. Extra fields from the app stay on the object. */
    export type AssistantCatalogItem = {
        route: string;
        kind: 'cmd' | 'qry';
        actionId: string;
        actors: string[];
        assistant: 'included' | 'excluded';
        title?: string;
        risk?: string;
        inputs?: Array<{
            path?: string;
            role?: string;
            [field: string]: unknown;
        }>;
        [field: string]: unknown;
    };
    /** Catalog file of one module, as `listAssistantCatalog` puts it on the wire. */
    export type AssistantCatalogDocument = {
        schemaVersion: typeof ASSISTANT_CATALOG_SCHEMA;
        module: string;
        commands: AssistantCatalogItem[];
        queries: AssistantCatalogItem[];
        [field: string]: unknown;
    };
    export type AssistantCatalogRequest = {
        kind: 'catalog';
        onBehalfOf: AssistantOnBehalfOf;
        knownRelease?: string;
    };
    export type AssistantCatalogEntry = {
        moduleId: string;
        catalog: AssistantCatalogDocument;
    };
    export type AssistantCatalogSuccess = {
        ok: true;
        outcome: 'done' | 'no_person';
        release: string;
        /** Absent when the app sees that this cm already holds `release`. */
        catalogs?: AssistantCatalogEntry[];
        allowed: string[];
        partial: AssistantActivityPartial[];
    };
    /** Finals the cm adds. `unknown`: the request left and the result was not read. */
    export type AssistantCallFailure = {
        ok: false;
        outcome: 'unavailable' | 'config_error' | 'rejected' | 'invalid' | 'unknown' | 'timeout_before_send';
        status?: number;
        code?: string;
    };
    export type AssistantCatalogResult = AssistantCatalogSuccess | AssistantCallFailure;
    export type AssistantExecOutcome = 'done' | 'refused_rule' | 'forbidden' | 'no_person' | 'not_found' | 'stale_version' | 'invalid_input' | 'unavailable';
    export type AssistantExecError = {
        code: string;
        message: string;
        /** Present on `forbidden`: actors that may run the action. */
        required?: string[];
    };
    export type AssistantExecRequest = {
        kind: 'exec';
        onBehalfOf: AssistantOnBehalfOf | AssistantOnBehalfOfAgent;
        actionId: string;
        commandId: string;
        input: unknown;
        expectVersion?: number;
    };
    /** `done` carries `data`. Every other app outcome carries `error`; `no_person` may come without it, and with `ASSISTANT_AGENT_NO_MEMBER` when an agent has no member yet. */
    export type AssistantExecSuccess = {
        ok: true;
        outcome: AssistantExecOutcome;
        data?: unknown;
        error?: AssistantExecError;
    };
    export type AssistantExecResult = AssistantExecSuccess | AssistantCallFailure;
    export type ModulePlanStep = {
        key: string;
        kind: ModuleStepKind;
        ownerKind: ModuleOwnerKind;
        actorRef?: string;
        journeyRef?: string;
        functionRef?: string;
        next: string[];
        title?: string;
        conditions?: string;
        params?: Record<string, string>;
    };
    export type ModulePlan = {
        processId: string;
        title: string;
        moduleTitle: string;
        steps: ModulePlanStep[];
    };
    export type TaskModuleExecutor = {
        kind: 'person';
        userId: string;
    } | {
        kind: 'routine';
        name: string;
    };
    export type TaskModuleHistoryEntry = {
        at: string;
        commandId: string;
        executor: TaskModuleExecutor;
        from: string | null;
        step: string;
        actorNow: string | null;
        done: boolean;
        note?: string;
        via?: 'nora';
        message?: {
            state: 'pending' | 'sent';
            threadId: string;
            orderAt?: string;
            content: string;
            author: 'person' | 'virtual';
            userId?: string;
        };
    };
    export interface TaskData {
        PK: string;
        SK: 'metadata';
        title: string;
        owner: string;
        team: 'unassigned' | string | null;
        assignees?: string[];
        dueDate?: string;
        status: TaskStatus;
        last_updated: 0 | number;
        last_update_log: string | null;
        source?: string;
        url?: string;
        description?: string;
        priority?: 'low' | 'normal' | 'high' | 'urgent';
        effort?: number;
        cost?: number;
        iaCompressed?: IACompressed;
        tags?: string[];
        attachmentsUrl?: string[];
        messageid_created?: string;
        messageid_refs?: string[];
        taskRoom?: {
            enabled: boolean;
            threadId?: string;
            workflowType?: WorkflowType;
            parentThreadId?: string;
            memoryRef?: string;
            status?: 'active' | 'archived' | 'deleted';
            pmaId?: string;
            pmaStatus?: "active" | "paused" | "disabled";
            pmaConfigRef?: string;
            lastDecisionLogRef?: string;
        };
        module?: {
            ref: TaskModuleRef;
            origin: ModuleOrigin;
            owner: string | null;
            revision: number;
            room: ModuleRoomChoice;
            moduleTitle: string;
            history: TaskModuleHistoryEntry[];
        };
    }
    export type TaskStatus = 'todo' | 'in progress' | 'paused' | 'done' | 'failed';
    export type WorkflowType = 'staticWorkflow' | 'dynamicWorkflow';
    export interface TaskDataToSave extends Omit<TaskData, 'iaCompressed'> {
        iaCompressed?: string;
    }
    export interface IACompressed {
        nextSteps: AIPayload[];
        longMemory: Record<string, string>;
        isTest?: boolean;
        queueBackEnd: AgentIntent[];
        queueFrontEnd: AgentHooks[];
    }
    export interface AIInteraction {
        input: IAMessageInputType[];
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
        cost: number;
        trace: string[];
        payload: AIPayload[] | null;
        /** Typed accounting evidence for one local E01 gateway request. */
        e01GatewayReceipt?: {
            localRequests: 1;
            providerAttempts: number | null;
            costChargedUsd: number | null;
            /** The model calls the gateway reported for this request, in order (kept on the execution record for the trace of the turn). */
            calls?: E01LlmCall[];
        };
    }
    /** One call of a model, as the gateway reported it. */
    export interface E01LlmCall {
        alias: string;
        model: string;
        stage?: string;
        inputTokens: number;
        outputTokens: number;
        /** Tokens of the output spent on reasoning, when the model reports them. */
        reasoningTokens?: number;
        /** Time of the call in milliseconds, when the gateway reports it. */
        ms?: number;
        costUsd: number;
        /** The error code of a call that failed. */
        error?: string;
    }
    export interface LLMTool {
        type: 'function';
        function: {
            name: string;
            description?: string;
            parameters?: Record<string, unknown>;
        };
    }
    export type LLMToolChoice = 'auto' | 'none' | 'required' | {
        type: 'function';
        function: {
            name: string;
        };
    };
    export interface IAMessageInputType {
        type: 'system' | 'human' | 'ai';
        content: string;
    }
    /**
     * Narrow transport-only input for the E02 audio worker. The regular agent
     * contract above deliberately remains text-only: audio bytes may exist only
     * while one bounded gateway request is being assembled.
     */
    export interface IAudioHumanMessageInputType {
        type: 'human';
        content: [
            {
                type: 'text';
                text: string;
            },
            {
                type: 'input_audio';
                input_audio: {
                    data: string;
                    format: 'mp3' | 'wav';
                };
            }
        ];
    }
    export type IProxyMessageInputType = IAMessageInputType | IAudioHumanMessageInputType;
    export type AIStepStatus = 'waiting_dependency' | // not ready yet
    'waiting_human_input' | // for parallel steps waiting for human input
    'waiting_after_prompt' | // for parallel steps waiting for afterPrompt processing
    'waiting_after_prompt_with_error' | // for parallel steps waiting for afterPrompt processing
    'pending' | // already created, waiting to be processed
    'in_progress' | // being processed in LLM
    'completed' | // completed successfully
    'failed';
    export interface AIStepProgress {
        total: number;
        completed: number;
        failed: number;
        templateTitle: string;
    }
    export type AIStepPlanningExecutionMode = 'sequential' | 'parallel_static' | 'parallel_dynamic' | 'manual_later';
    export interface AIStepPlanningDynamicSource {
        sourcePlanId?: string;
        selectorField?: string;
        argsField?: string;
    }
    export interface AIStepPlanning {
        planId: string;
        dependsOn: string[];
        executionMode: AIStepPlanningExecutionMode;
        executionHost?: 'client' | 'server' | 'either';
        dynamicSource?: AIStepPlanningDynamicSource;
    }
    export interface AIStep {
        type: AIPayload['type'];
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
    }
    export interface AIModuleStep extends AIStep {
        type: 'module';
        interaction: null;
        module: {
            key: string;
            kind: ModuleStepKind;
            ownerKind: ModuleOwnerKind;
            actorRef?: string;
            journeyRef?: string;
            functionRef?: string;
            next: string[];
            conditions?: string;
            params?: Record<string, string>;
            actorNow?: string | null;
            wake?: ModuleWake;
            passes: number;
        };
    }
    export type AIPayload = AIAgentStep | AIToolStep | AIClarificationStep | AIResultStep | AIFlexibleResultStep | AIModuleStep;
    export interface AIWorkflowStep {
        type: WorkflowType;
        stepId: number;
        status: AIStepStatus;
        stepTitle?: string;
        progress?: AIStepProgress;
        planning?: AIStepPlanning;
        interaction: AIInteraction | null | undefined;
        nextSteps: AIPayload[] | null;
        workflowName?: string;
    }
    export interface AIAgentStep extends AIStep {
        type: 'agent';
        agentName: string;
        /** Private service-step controls consumed only by the existing backend scheduler. */
        e01Execution?: {
            schemaVersion: 1;
            executionId: string;
            organizationId: string;
            userId: string;
            threadId?: string;
            manifestRef: string;
            maxAttempts: 1;
            maxOutputTokens: number;
            deadlineAt: string;
            executionMode?: 'bounded' | 'legacy-supervised-pilot';
            /** Set only for Nora: the organization LLM limit applies, with no per-call pilot. */
            organizationBilling?: boolean;
            pilotId?: string;
            pilotExpiresAt?: string;
            pilotOperationalBudgetUsd?: number;
            pilotLocalRequestLimit?: 6;
            pilotNextRequestCostEstimateUsd?: number;
        };
        /** Identity of a module LLM request. Absent on agent-task steps. */
        moduleLlm?: {
            commandId: string;
            stepKey: string;
            pass: number;
        };
        /** Compact E02 identity. Audio bytes and transcript text never enter TaskRecord. */
        e02Audio?: {
            schemaVersion: 1;
            processingId: string;
            executionId: string;
            organizationId: string;
            ownerUserId: string;
            threadId: string;
            phase: 'transcription' | 'interpretation';
        };
        prompt?: string;
        rags: string[] | null;
        onFailure?: 'fail' | 'continue' | 'wait_after_prompt' | 'skip';
    }
    export interface AIToolStep extends AIStep {
        type: 'tool';
        toolName: string;
        args: string;
    }
    export interface AIClarificationStep extends AIStep {
        type: 'clarification';
        json?: string;
    }
    export interface AIResultStep extends AIStep {
        type: 'result';
        result: string;
    }
    export interface AIFlexibleResultStep extends AIStep {
        type: 'flexible';
        result: any;
    }
    export interface ExecutionContext {
        message: Message;
        task: TaskData | undefined;
        isTest: boolean;
    }
    export type AgentIntentUpdateStatus = {
        type: 'update-status';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        stepId: number;
        status: AIStepStatus;
        traceMsg?: string;
        cleaner?: 'input' | 'input_output';
        newTaskTitle?: string;
    };
    export type AgentIntentAddStep = {
        type: 'add-step';
        messageId: string;
        threadId: string;
        taskId: string;
        parentStepId: number;
        step: AIPayload;
        stepTitle?: string;
        executionMode?: ExecutionMode;
    };
    export type AgentIntentPauseOrContinue = {
        type: 'pause-or-continue';
        messageId: string;
        threadId: string;
        taskId: string;
        reason: string;
    };
    export type AgentIntentAddMessageAI = {
        type: 'add-message-ai';
        stepTitle?: string;
        request: Omit<RequestAddMessageAI, 'userId'>;
        executionMode?: ExecutionMode;
        skipRootLLM?: boolean;
    };
    export type ExecutionMode = {
        type: 'parallel';
        args: string[];
        maxParallel?: number;
    };
    /**
     * Parallel steps execution mechanism.
     * Child steps inherit the system prompt from their parent step.
     * Human prompts are prepared client-side using compact args (via beforePrompt hook).
     * Keep args short, unique, and deterministic.
     *
     * Parallel execution flow:
     *
     * 1. Frontend requests creation of a parent step (via API) with system prompt only
     *    and one or more AgentIntentParallelSteps.
     *
     * 1.1 Frontend enforces max parallel items per request.
     *     Use pagination (offset/limit or batch markers) in args when more items exist.
     *
     * 2. Backend:
     *    - Creates parent step with status "in_progress"
     *    - Enqueues AgentIntentParallelSteps in queueBackEnd
     *    - Immediately creates a batch of "waiting_human_input" child steps (no human prompt yet)
     *
     * 2.1 Parent remains "in_progress" until all children reach terminal state ("completed" or "failed").
     *
     * 2.2 Child steps are pre-allocated and reused as prompts arrive.
     *
     * 3. Backend enqueues multiple AgentHookBeforePrompt (one per waiting_human_input child) for frontend.
     *
     * 4. Frontend prepares human prompts and returns AgentIntentContinueParallelStep items.
     *
     * 5. Backend:
     *    - Updates child steps with received human prompts
     *    - Applies strong deduplication (ignore duplicates by parentStepId + args)
     *    - Cleans queueBackEnd and queueFrontEnd
     *
     * 6. Backend executes child steps as they become ready.
     *
     * 6.1 After each child execution, backend sends feedback AgentHook to frontend
     *     (success or error). Frontend then requests child status update to "completed" or "failed".
     *
     * 7. When ALL children are in terminal state, backend finalizes the parent step.
     *
     * 7.1 Finished child steps are deleted to reduce task object size.
     *
     * Critical implementation notes:
     * - Uniqueness key: parentStepId + args (must be collision-resistant)
     * - Step 5 MUST implement strict idempotency and duplicate rejection
     * - Error handling, child retries, and stuck-state timeouts are responsibility of other system layers
     */
    export type AgentIntentParallelSteps = {
        type: 'parallel-steps';
        parentStepId: number;
        args: string;
    };
    export type AgentIntentPromptReady = {
        type: 'prompt_ready';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
        parentStepId: number;
        args: string;
        humanPrompt: string;
        systemPrompt?: string;
        tools?: LLMTool[];
        toolChoice?: LLMToolChoice;
    };
    export type AgentIntentRemoveHook = {
        type: 'remove-hook';
        messageId: string;
        threadId: string;
        taskId: string;
        hookSequential: number;
    };
    export type AgentIntentModuleAdvance = {
        type: 'module-advance';
        taskId: string;
        commandId: string;
        expectedRevision: number;
        from: string;
        to: string;
        actorNow: string | null;
        done?: boolean;
        note?: string;
        via?: 'nora';
        executor: TaskModuleExecutor;
        wake?: Omit<ModuleWake, 'nextAt' | 'seq'>;
        message?: {
            content: string;
        };
    };
    export type AgentIntent = AgentIntentAddStep | AgentIntentPauseOrContinue | AgentIntentUpdateStatus | AgentIntentParallelSteps | AgentIntentPromptReady | AgentIntentAddMessageAI | AgentIntentRemoveHook | AgentIntentModuleAdvance;
    export type AgentHookBase = {
        hookSequential: number;
        stepId: number;
    };
    export type AgentHookBeforePromptStep = AgentHookBase & {
        type: 'beforePromptStep';
        parentStepId: number;
        args: string;
    };
    export type AgentHookBeforeTool = AgentHookBase & {
        type: 'beforeTool';
        parentStepId: number;
        args: string;
    };
    export type AgentHookAfterPromptStep = AgentHookBase & {
        type: 'afterPromptStep';
        parentStepId: number;
    };
    export type AgentHookPooling = AgentHookBase & {
        type: 'pooling';
        executionCount: number;
        afterMs: number;
    };
    export type AgentHooks = AgentHookBeforePromptStep | AgentHookAfterPromptStep | AgentHookPooling | AgentHookBeforeTool;
    /** The seven answers a caller tells apart. Never a silent error. */
    export type ConnectionErrorCode = 'not_found' | 'disabled' | 'unavailable' | 'conflict' | 'refused' | 'forbidden' | 'invalid';
    /** Who the call is about, outside `input`. `actorUserId` is the id of the user in the cm. */
    export interface ConnectionContext {
        organizationId: string;
        actorUserId?: string;
        actorMdmId?: string;
        customerId?: string;
        agentId?: string;
        requestedBy?: string;
    }
    export interface RequestConnectionCall extends RequestBase {
        action: 'connectionCall';
        connectionId: string;
        operationId: string;
        input: unknown;
        context: ConnectionContext;
        idempotencyKey?: string;
        expectVersion?: string;
    }
    export interface ResponseConnectionCallOk {
        statusCode: HttpStatus.OK;
        ok: true;
        output: unknown;
    }
    export interface ResponseConnectionCallFailure {
        statusCode: HttpStatus;
        ok: false;
        code: ConnectionErrorCode;
        message: string;
    }
    export type ResponseConnectionCall = ResponseConnectionCallOk | ResponseConnectionCallFailure;
    /** The catalog item of a module as it is today (`ToolCatalogItem` of the harness): the id and the kind, and every other field the module sends. */
    export type CmToolEntry = {
        actionId: string;
        kind: 'cmd' | 'qry';
        [field: string]: unknown;
    };
    /** A tool of an agent: module, subject, action, with the purpose, the kind and the whole catalog item of the module. */
    export interface CmTool {
        moduleId: string;
        moduleTitle?: string;
        subject: string;
        subjectTitle?: string;
        actionId: string;
        title?: string;
        purpose: string;
        kind: 'cmd' | 'qry';
        entry: CmToolEntry;
    }
    export type CmAgentAudience = 'member' | 'room' | 'external';
    export type CmDraftStatus = 'preparing' | 'ready' | 'refused';
    /** What a company can adjust; `key` is a dotted name of the override of the configuration of the cm, `label` is in the language of the answer. */
    export interface CmAgentLimit {
        key: string;
        label: string;
        kind: 'number' | 'text' | 'boolean';
        value: number | string | boolean;
        max?: number;
    }
    export type CmAgentLimits = CmAgentLimit[];
    export interface CmAgentCard {
        agentId: string;
        name: string;
        audience: CmAgentAudience;
        enabled: boolean;
        responsibleUserId?: string;
        draftStatus?: CmDraftStatus;
        refusedReason?: string;
    }
    export interface CmListAgentsInput {
        includeDrafts?: boolean;
    }
    export interface CmListAgentsOutput {
        agents: CmAgentCard[];
    }
    export interface CmReadAgentInput {
        agentId: string;
    }
    export interface CmReadAgentOutput {
        agentId: string;
        name: string;
        audience: CmAgentAudience;
        definition: string;
        role: string;
        state: string;
        enabled: boolean;
        responsibleUserId?: string;
        limits: CmAgentLimits;
        /** The member of the agent in the mdm of the app that asks; absent before the agent is active. */
        mdmId?: string;
        personal?: {
            role: string;
            state: string;
        };
        version: string;
    }
    export type CmListCmToolsInput = Record<string, never>;
    export interface CmListCmToolsOutput {
        tools: CmTool[];
    }
    /** What `updateAgent` sends for a limit: the `key` of the limits `readAgent` answers. */
    export interface CmAgentLimitValue {
        key: string;
        value: number | string | boolean;
    }
    /**
     * Change by prompt, or by field (turn on or off, the responsible, the limits). Exactly one way per call. The author is
     * `context.actorUserId`, and the version the caller read goes in `expectVersion`. With `scope: 'personal'` only `prompt` is accepted:
     * it changes the conduct of the person of the context, not the agent of the company.
     */
    export interface CmUpdateAgentInput {
        agentId: string;
        scope?: 'company' | 'personal';
        /**
         * The name the agent is called by in the chat (`@<name>`): one word of 2 to 24 characters, with letters, digits, `.`, `_` or `-`.
         * Out of that form the cm answers `invalid`; a name already used answers `conflict`.
         */
        name?: string;
        prompt?: string;
        enabled?: boolean;
        responsibleUserId?: string;
        limits?: CmAgentLimitValue[];
    }
    export interface CmUpdateAgentOutput {
        version: string;
        /** What `undoAgentChange` takes. */
        changeId: string;
        /** One-line summary of what a prompt change altered, made by the cm. */
        summary?: string;
    }
    export interface CmListAgentHistoryInput {
        agentId: string;
    }
    export interface CmAgentChange {
        changeId: string;
        /** ISO 8601. */
        at: string;
        authorUserId: string;
        /** One-line summary of what a prompt change altered, made by the cm. */
        summary?: string;
    }
    export interface CmListAgentHistoryOutput {
        changes: CmAgentChange[];
    }
    export interface CmUndoAgentChangeInput {
        agentId: string;
        changeId: string;
    }
    export interface CmUndoAgentChangeOutput {
        version: string;
    }
    /** What a call of the cm to an app through `/exec/connection` answers: the output, or one of the seven codes. */
    export type ConnectionResult<Output = unknown> = {
        ok: true;
        output: Output;
    } | {
        ok: false;
        code: ConnectionErrorCode;
        message: string;
    };
    /** The body of `POST /exec/connection` on an app (the cm calls the module). */
    export interface RequestConnectionExec {
        connectionId: string;
        operationId: string;
        input: unknown;
        context: ConnectionContext;
        idempotencyKey?: string;
    }
    /** What the cm tells the module about one execution of an agent (`record`): numbers and ids, never the text of the conversation. */
    export type CmRecordOutcome = 'done' | 'refused_rule' | 'forbidden' | 'no_person' | 'not_found' | 'stale_version' | 'invalid_input' | 'unavailable';
    export interface CmRecordInput {
        /** The identity of the execution; a repeat does not record again. */
        executionId: string;
        agentId: string;
        /** Whether it counted (`real`) or was a rehearsal. */
        mode: 'real' | 'rehearsal';
        /** ISO 8601. */
        startedAt: string;
        durationMs: number;
        costUsd: number;
        actions: Array<{
            actionId: string;
            outcome: CmRecordOutcome;
        }>;
        usedMainModel: boolean;
        handedOff: boolean;
        refs: {
            conversationId?: string;
            taskId?: string;
            messageId?: string;
        };
    }
    export interface CmRecordOutput {
        status: 'recorded' | 'existing';
    }
    /** The cm asks the app to make the agent a member of the organization: create it, or set its name and whether it is active. Never deleted. */
    export interface CmEnsureAgentMemberInput {
        agentId: string;
        name: string;
        active: boolean;
    }
    export interface CmEnsureAgentMemberOutput {
        mdmId: string;
    }
    /** The levels of the first version of the simulation: what the agent can, and what it understands. Nothing is saved. */
    export type CmSimulationLevel = 'canDo' | 'understands';
    export interface CmSimulateAgentInput {
        /** The id of an agent, or of a draft (`draftId`). */
        agentId: string;
        level: CmSimulationLevel;
        /** Whom to simulate: the id of the user in the cm, or a role `<moduleId>:<actorId>`. Missing: the one who simulates (`context.actorUserId`). */
        as?: string;
        /** For `understands`: the sentence. */
        message?: string;
        /** To simulate a behavior not saved yet. */
        draftInstructions?: string;
    }
    export interface CmSimulationCanDoRow {
        actionId: string;
        allowed: boolean;
        /** Why it can or cannot. */
        reason: string;
    }
    export interface CmSimulateAgentOutput {
        level: CmSimulationLevel;
        /** canDo: every tool the agent has with "can"/"cannot" and the reason; and the context that would be sent. */
        tree?: CmSimulationCanDoRow[];
        context?: Record<string, unknown>;
        /** understands: whether the sentence is a request for an action, the path of the tree, and the actions. */
        isActionRequest?: boolean;
        path?: string[];
        actions?: string[];
    }
    export interface CmCreateAgentInput {
        /** The text of the person: what the agent is and what it does. */
        prompt: string;
        /** The catalog of tools, so the cm can suggest tools in the same call. The whole catalog travels only here and in `runAiPrompt`. */
        catalog?: CmTool[];
    }
    export interface CmCreateAgentOutput {
        /** The result comes later, through `agentDraftReady`. */
        draftId: string;
    }
    export interface CmActivateAgentInput {
        draftId: string;
    }
    export interface CmActivateAgentOutput {
        /** The `draftId` of `createAgent` is already the final id: this is the same value, not a new one. */
        agentId: string;
    }
    export interface CmDiscardAgentDraftInput {
        draftId: string;
    }
    export interface CmDiscardAgentDraftOutput {
        discarded: true;
    }
    export interface CmRunAiPromptInput {
        prompt: string;
        /** The format of the answer the caller wants: a JSON schema. */
        outputFormat: Record<string, unknown>;
    }
    export interface CmRunAiPromptOutput {
        result: unknown;
    }
    /** What the cm tells the module when the preparation of a draft ends (`agentDraftReady`). */
    export interface CmAgentDraftReadyInput {
        draftId: string;
        status: 'ready' | 'refused';
        /** When refused: the reason in words, the same as `refusedReason` of the card. */
        refusedReason?: string;
        /** When ready: the tools the model suggests, by action id. */
        suggestedTools?: string[];
    }
    export type CmAgentDraftReadyOutput = Record<string, never>;
    export * from "_102036_/l2/shared/interfacesFrontend";
}
declare module "_102036_/l2/collabMessagesIndexedDB" {
    import * as msg from "_102036_/l2/shared/interfaces";
    export function openDB(): Promise<IDBDatabase>;
    /** Empties every store of the local chat database (rooms, users, messages, tasks, poolings): what it holds belongs to the user who is gone. */
    export function clearAllLocalData(): Promise<void>;
    export function addMessages(messages: msg.MessagePerformanceCache[]): Promise<void>;
    export function addMessage(message: msg.MessagePerformanceCache): Promise<void>;
    export function updateMessage(message: msg.Message): Promise<void>;
    export function deleteAllMessagesFromThread(threadId: string): Promise<void>;
    export function getMessage(messageId: string): Promise<msg.MessagePerformanceCache | undefined>;
    export function getMessagesByThreadId(threadId: string, limit?: number, offset?: number): Promise<msg.MessagePerformanceCache[]>;
    export function getAllMessagesByThreadId(threadId: string): Promise<msg.MessagePerformanceCache[]>;
    export function addOrUpdateTask(task: msg.TaskData): Promise<void>;
    export function getTask(taskId: string): Promise<msg.TaskData | undefined>;
    export function deleteTask(taskId: string): Promise<void>;
    export function listThreads(): Promise<msg.ThreadPerformanceCache[]>;
    export function addThread(thread: msg.Thread): Promise<msg.ThreadPerformanceCache>;
    export function updateLastMessageReadTime(threadId: string, lastMessageReadTime: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreadPendingTasks(threadId: string, taskId?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThread(threadId: string, thread: msg.Thread, lastMessage?: string, lastMessageTime?: string, unreadCount?: number, lastSync?: string): Promise<IDBThreadPerformanceCache>;
    export function updateThreads(threadsFromServer: msg.Thread[]): Promise<void>;
    export function getThread(threadId: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getThreadByName(threadName: string): Promise<IDBThreadPerformanceCache | undefined>;
    export function getAllThreads(): Promise<IDBThreadPerformanceCache[]>;
    export function cleanupThreads(validThreadIds: string[]): Promise<void>;
    export function listUsers(): Promise<msg.User[]>;
    export function addUser(user: msg.User): Promise<void>;
    export function updateUsers(usersFromServer: msg.User[]): Promise<void>;
    /**
     * Who in the local copy of users has no reason to stay: not in `keepUserIds`, not a member of any local room (a room deleted with unread
     * messages included: `cleanupThreads` keeps it) and not the user of an agent bound to one. When in doubt nothing goes: no local room at all
     * (first load, a failed read) or no id to keep means an empty list.
     */
    export function usersToRemove(threads: ReadonlyArray<{
        users?: ReadonlyArray<{
            userId: string;
        }>;
        openClawAgents?: ReadonlyArray<{
            collabUserId: string;
        }>;
    }>, users: ReadonlyArray<{
        userId: string;
    }>, keepUserIds: ReadonlyArray<string>): string[];
    /** The local copy of users is a cache: whoever was dropped and still exists comes back when a room is read (`updateUsers`). A failure on one id is a warning. */
    export function cleanupUsers(keepUserIds: string[]): Promise<void>;
    export function getUser(userId: string): Promise<msg.User | undefined>;
    export function addPooling(pooling: PoolingTask): Promise<void>;
    export function deletePooling(taskId: string): Promise<void>;
    export function getPooling(taskId: string): Promise<PoolingTask | undefined>;
    export function listPoolings(): Promise<PoolingTask[]>;
    export function getCompactUTC(): string;
    export interface IDBThreadPerformanceCache extends msg.ThreadPerformanceCache {
        pendingTasks?: string;
    }
    export interface PoolingTask {
        taskId: string;
        userId: string;
        startAt: string;
    }
}
declare module "_102036_/l2/designSystem" {
    export const tokens: IDesignSystemTokens[];
    export interface IDesignSystemTokens {
        description: string;
        themeName: string;
        color: Record<string, string>;
        global: Record<string, string>;
        typography: Record<string, string>;
    }
    export interface IDesignSystem {
        tokens: IDesignSystemTokens[];
    }
    interface IKeyValueToken {
        [x: string]: string;
    }
    export interface IDarkLight {
        [theme: string]: IKeyValueToken;
    }
}
declare module "_102036_/l2/environmentContract.defs" {
    export const asis: mls.defs.AsIs;
}
declare module "_102036_/l2/environmentContract" {
    import { IAgentMeta, IOpenClawIntegration, Thread, ToolsBeforeSendMessage, ExecutionContext, TaskData, Message, PushSubscriptionData } from "_102036_/l2/shared/interfaces";
    export interface CollabProgramMenuItem {
        title: string;
        /** Lucide icon name; '' when the item has none. */
        icon: string;
        /** Own SVG markup (`navigation[i].iconSvg`), already checked by isSafeMenuIconSvg; wins over `icon`. */
        iconSvg?: string;
        url: string;
        pageName: string;
        target?: string;
        children?: CollabProgramMenuItem[];
    }
    export interface CollabProgramMenu {
        name: string;
        icon: string;
        project: number;
        path: string;
        menu: CollabProgramMenuItem[];
    }
    /**
     * CONTRACT
     */
    export interface CollabMessagesEnvironment {
        getAgents?(): Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw?(): Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw?(integrations: IOpenClawIntegration[]): Promise<void>;
        config?: {
            getMenuMode?(): 'default' | 'custom';
            generateSvgAvatarEnabled?(): boolean;
            getApiUrl?(): string;
            getApiCredentials?(): RequestCredentials;
            getDefaultUserName?(): string;
        };
        tasks?: {
            openTaskDetails?(messageId: string, taskId: string, task: TaskData, message: Message): Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        apps?: {
            getProgramMenu?(): Promise<CollabProgramMenu[]>;
            openProgram?(item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }): Promise<void>;
        };
        agents?: {
            loadAgent?(agentName: string): Promise<IAgentMeta | null>;
            executeAgent?(agentToCall: string, context: ExecutionContext): Promise<void>;
            generateSvgAvatar?(threadId: string, userId: string, promptToAvatar: string): Promise<string | null>;
        };
        notifications?: {
            getPushSubscriptionForBackend?(): Promise<PushSubscriptionData | null>;
            getNotifySoundUrl?(): Promise<string | null>;
            sendRequestMissed?(): Promise<void>;
            sendACK?(id: string): Promise<void>;
        };
        bots?: {
            getArgsToBots?(): Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend?(thread: Thread, messageText: string): Promise<string[]>;
            getBotContextVarsBeforeMessageSend2?(vars: string[], myArgs: Record<string, any>): Promise<ToolsBeforeSendMessage[]>;
        };
        details?: {
            openContent?(input: DetailContentInput): Promise<boolean>;
        };
    }
    export interface DetailContentInput {
        id: string;
        title: string;
        element: HTMLElement;
    }
    export function setEnvironment(env: CollabMessagesEnvironment): void;
    /**
     * FACADE FINAL
     */
    export const environment: {
        getAgents: () => Promise<IAgentMeta[]>;
        getIntegrationsOpenClaw: () => Promise<IOpenClawIntegration[]>;
        setIntegrationsOpenClaw: (integrations: IOpenClawIntegration[]) => Promise<void>;
        notifications: {
            getPushSubscriptionForBackend: () => Promise<PushSubscriptionData>;
            getNotifySoundUrl: () => Promise<string>;
            sendRequestMissed: () => Promise<void>;
            sendACK: (id: string) => Promise<void>;
        };
        bots: {
            getArgsToBots: () => Promise<Record<string, any>>;
            getBotContextVarsBeforeMessageSend: (thread: Thread, messageText: string) => Promise<string[]>;
            getBotContextVarsBeforeMessageSend2: (vars: string[], myArgs: Record<string, any>) => Promise<ToolsBeforeSendMessage[]>;
        };
        agents: {
            generateSvgAvatar: (threadId: string, userId: string, promptToAvatar: string) => Promise<string>;
            executeAgent: (agentToCall: string, context: ExecutionContext) => Promise<void>;
            loadAgent: (agentName: string) => Promise<IAgentMeta>;
        };
        tasks: {
            openTaskDetails: (messageId: string, taskId: string, task: TaskData, message: Message) => Promise<{
                openLocal: boolean;
                element: HTMLElement | undefined;
            }>;
        };
        details: {
            openContent: (input: DetailContentInput) => Promise<boolean>;
        };
        apps: {
            getProgramMenu: () => Promise<CollabProgramMenu[]>;
            openProgram: (item: CollabProgramMenuItem & {
                project?: number;
                module?: string;
                path?: string;
            }) => Promise<void>;
        };
        config: {
            getMenuMode: () => "default" | "custom";
            generateSvgAvatarEnabled: () => boolean;
            getApiUrl: () => string;
            getApiCredentials: () => RequestCredentials;
            getDefaultUserName: () => string;
        };
    };
}
declare module "_102036_/l2/inlineSvg" {
    export interface InlineSvgOptions {
        /** Size cap of the markup, in characters. */
        maxBytes: number;
        /** Only currentColor paint: what makes the drawing follow the theme (light and dark). */
        monochrome?: boolean;
    }
    /** Cap for an apps-menu icon: a hand-drawn 24x24 stroke icon sits far below it. */
    export const MAX_MENU_ICON_SVG_BYTES = 4000;
    export type InlineSvgProblem = 'empty' | 'too-large' | 'not-svg' | 'many-roots' | 'no-viewbox' | 'forbidden' | 'event-handler' | 'external-url' | 'root-size' | 'fixed-color';
    /** Why the markup would be refused, in a stable order; empty when it is fine. */
    export function inlineSvgProblems(markup: unknown, options: InlineSvgOptions): InlineSvgProblem[];
    /** Whether the markup is safe AND suitable to be inlined (see inlineSvgProblems). */
    export function isSafeInlineSvg(markup: unknown, options: InlineSvgOptions): boolean;
    /** The rule for an apps-menu icon: monochrome and small. */
    export function isSafeMenuIconSvg(markup: unknown): boolean;
    /**
     * The `iconSvg` of a config navigation item as the apps menu may carry it: the trimmed markup when it
     * passes the rule, otherwise undefined (logged once per item, so a broken config is visible).
     */
    export function readMenuIconSvg(value: unknown, where: string): string | undefined;
    /** The problems of an apps-menu icon (same rule as isSafeMenuIconSvg). */
    export function menuIconSvgProblems(markup: unknown): InlineSvgProblem[];
}
declare module "_102036_/l2/lucideArtwork" {
    export const LUCIDE_ARTWORK_VERSION = "1.62.0";
    export function lucideArtwork(name: string): string | undefined;
}
declare module "_102036_/l2/project" {
    export const projectConfig: {
        masterFrontEnd: {
            build: string;
            start: string;
            liveView: string;
        };
        masterBackEnd: {
            build: string;
            start: string;
            serverView: string;
        };
        modules: any[];
    };
}
declare module "_102036_/l2/shared/api" {
    import * as msg from "_102036_/l2/shared/interfaces";
    type IdentityRefusedHandler = () => Promise<string>;
    /**
     * Registers the one handler that runs when the cm refuses the saved identity: it drops what was saved for the old user and returns the id of the
     * person the token belongs to. Registering again replaces it; `undefined` removes it (and forgets the swaps made).
     */
    export function setIdentityRefusedHandler(handler: IdentityRefusedHandler | undefined): void;
    export function post<T = msg.ResponseBase>(args: msg.RequestBase): Promise<T>;
    export function getPostError(response: Response, args: msg.RequestBase): Promise<Error>;
    export function msgGetUsers(args: Omit<msg.RequestGetUsers, "action">): Promise<ApiResult<msg.ResponseGetUsers>>;
    export function msgGetUserUpdate(args: Omit<msg.RequestGetUserUpdate, "action">): Promise<ApiResult<msg.ResponseGetUserUpdate>>;
    export function msgUpdateUserDetails(args: Omit<msg.RequestUpdateUserDetails, "action">): Promise<ApiResult<msg.ResponseUpdateUserDetails>>;
    export function msgAddThread(args: Omit<msg.RequestAddThread, "action">): Promise<ApiResult<msg.ResponseAddThread>>;
    export function msgUpdateThread(args: Omit<msg.RequestUpdateThread, "action">): Promise<ApiResult<msg.ResponseUpdateThread>>;
    export function msgRemoveParticipantFromThread(args: Omit<msg.RequestRemoveUserInThread, "action">): Promise<ApiResult<msg.ResponseRemoveUserInThread>>;
    export function msgAddParticipantToThread(args: Omit<msg.RequestAddUserInThread, "action">): Promise<ApiResult<msg.ResponseAddUserInThread>>;
    export function msgGetThreadUpdates(args: Omit<msg.RequestGetThreadUpdate, "action">): Promise<ApiResult<msg.ResponseGetThreadUpdate>>;
    export function msgGetTaskUpdate(args: Omit<msg.RequestGetTaskUpdate, "action">): Promise<ApiResult<msg.ResponseGetTaskUpdate>>;
    export function msgAddMessage(args: Omit<msg.RequestAddMessage, "action">): Promise<ApiResult<msg.ResponseAddMessage>>;
    export function msgCreateAttachmentUpload(args: Omit<msg.RequestCreateAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCreateAttachmentUpload>>;
    export function msgCompleteAttachmentUpload(args: Omit<msg.RequestCompleteAttachmentUpload, "action">): Promise<ApiResult<msg.ResponseCompleteAttachmentUpload>>;
    export function msgReportAttachmentUploadFailure(args: Omit<msg.RequestReportAttachmentUploadFailure, "action">): Promise<ApiResult<msg.ResponseReportAttachmentUploadFailure>>;
    export function msgDeleteAttachment(args: Omit<msg.RequestDeleteAttachment, "action">): Promise<ApiResult<msg.ResponseDeleteAttachment>>;
    export function msgGetAttachmentUrl(args: Omit<msg.RequestGetAttachmentUrl, "action">): Promise<ApiResult<msg.ResponseGetAttachmentUrl>>;
    export function msgEnsureTaskRoom(args: Omit<msg.RequestEnsureTaskRoom, "action">): Promise<ApiResult<msg.ResponseEnsureTaskRoom>>;
    export function msgAddMessageAI(args: Omit<msg.RequestAddMessageAI, "action">): Promise<ApiResult<msg.ResponseAddMessageAI>>;
    export function msgAddOrUpdateThreadBot(args: Omit<msg.RequestAddOrUpdateThreadBot, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadBot>>;
    export function msgAddOrUpdateThreadIntegration(args: Omit<msg.RequestAddOrUpdateThreadIntegration, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadIntegration>>;
    export function msgGetMessagesAfter(args: Omit<msg.RequestGetMessagesAfter, "action">): Promise<ApiResult<msg.ResponseGetMessagesAfter>>;
    export function msgGetMessagesBefore(args: Omit<msg.RequestGetMessagesBefore, "action">): Promise<ApiResult<msg.ResponseGetMessagesBefore>>;
    export function msgGetMessage(args: Omit<msg.RequestGetMessage, "action">): Promise<ApiResult<msg.ResponseGetMessage>>;
    export function msgUpdateMessage(args: Omit<msg.RequestUpdateMessage, "action">): Promise<ApiResult<msg.ResponseUpdateMessage>>;
    export function msgAddOrUpdateOpenClawConnector(args: Omit<msg.RequestAddOrUpdateOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateOpenClawConnector>>;
    export function msgRemoveOpenClawConnector(args: Omit<msg.RequestRemoveOpenClawConnector, "action">): Promise<ApiResult<msg.ResponseRemoveOpenClawConnector>>;
    export function msgListOpenClawConnectors(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListOpenClawConnectorAgents(args: Omit<msg.RequestListOpenClawConnectors, "action">): Promise<ApiResult<msg.ResponseListOpenClawConnectors>>;
    export function msgListThreadOpenClawAgents(args: Omit<msg.RequestListThreadOpenClawAgents, "action">): Promise<ApiResult<msg.ResponseListThreadOpenClawAgents>>;
    export function msgAddOrUpdateThreadOpenClawAgent(args: Omit<msg.RequestAddOrUpdateThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseAddOrUpdateThreadOpenClawAgent>>;
    export function msgRemoveThreadOpenClawAgent(args: Omit<msg.RequestRemoveThreadOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseRemoveThreadOpenClawAgent>>;
    export function msgCreateOpenClawAgent(args: Omit<msg.RequestCreateOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseCreateOpenClawAgent>>;
    export function msgDeleteOpenClawAgent(args: Omit<msg.RequestDeleteOpenClawAgent, "action">): Promise<ApiResult<msg.ResponseDeleteOpenClawAgent>>;
    export function msgListOpenClawAvailableAgents(args: Omit<msg.RequestListOpenClawAvailableAgents, "action">): Promise<ApiResult<msg.ResponseListOpenClawAvailableAgents>>;
    export type ApiResult<T> = {
        success: boolean;
        response?: T;
        error?: string;
        statusCode: number;
    };
    export function msgApplyIntents(args: Omit<msg.RequestApplyIntents, "action">): Promise<msg.ResponseApplyIntents>;
    export function msgAppendLongTermMemory(args: Omit<msg.RequestAppendLongTermMemory, "action">): Promise<msg.ResponseAppendLongTermMemory>;
}
declare module "_102036_/l2/shared/interfaces.defs" {
    export const asis: mls.defs.AsIs;
}
