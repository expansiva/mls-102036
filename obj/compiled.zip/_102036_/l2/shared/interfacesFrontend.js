/// <mls fileReference="_102036_/l2/shared/interfacesFrontend.ts" enhancement="_blank"/>
export {};
