/// <mls fileReference="_102036_/l2/shared/api.ts" enhancement="_blank"/>
import * as msg from '/_102036_/l2/shared/interfaces.js';
import { environment } from '/_102036_/l2/environmentContract.js';
async function handleRequest(promise) {
    try {
        const res = await promise;
        if (res.statusCode >= 200 && res.statusCode < 300) {
            return {
                success: true,
                response: res,
                statusCode: res.statusCode
            };
        }
        return {
            success: false,
            error: res?.msg || 'Request failed',
            statusCode: res.statusCode
        };
    }
    catch (err) {
        return {
            success: false,
            error: err?.message || 'Unexpected error',
            statusCode: err?.statusCode || 500
        };
    }
}
/** What the cm answers (403) when the `userId` of the body is not the person of the token. */
const IDENTITY_REFUSED = 'userId does not match authenticated user';
let identityRefusedHandler;
let identitySwapInFlight;
/** Old id -> the id that replaced it: a call refused a moment after the swap reuses it instead of swapping again. */
const swappedIds = new Map();
/**
 * Registers the one handler that runs when the cm refuses the saved identity: it drops what was saved for the old user and returns the id of the
 * person the token belongs to. Registering again replaces it; `undefined` removes it (and forgets the swaps made).
 */
export function setIdentityRefusedHandler(handler) {
    identityRefusedHandler = handler;
    identitySwapInFlight = undefined;
    swappedIds.clear();
}
function isIdentityRefused(error) {
    const failure = error;
    return failure?.statusCode === msg.HttpStatus.FORBIDDEN && typeof failure.message === 'string' && failure.message.includes(IDENTITY_REFUSED);
}
/** The id of the person after the swap for `oldId`; calls refused together wait for the same swap. A failure of the handler is logged and thrown. */
async function swapIdentity(oldId) {
    const done = swappedIds.get(oldId);
    if (done)
        return done;
    const handler = identityRefusedHandler;
    if (!handler)
        throw new Error('No handler for a refused identity');
    if (!identitySwapInFlight) {
        identitySwapInFlight = handler().then((newId) => {
            identitySwapInFlight = undefined;
            swappedIds.set(oldId, newId);
            return newId;
        }, (error) => {
            identitySwapInFlight = undefined;
            console.error('Could not replace the refused identity', error);
            throw error;
        });
    }
    const newId = await identitySwapInFlight;
    swappedIds.set(oldId, newId);
    return newId;
}
/** What the cm answers (409) for a room it does not hold: `Thread not found: <threadId>` (after `DomainError: ` on the client). */
const THREAD_NOT_FOUND = /Thread not found: ([^\s,;]+)/;
let threadNotFoundHandler;
/** The rooms the handler already ran for: a room that keeps failing (every sync) does not run it again. */
const threadsGone = new Set();
/** Registers the one handler that runs with the id of a room the cm does not know. Registering again replaces it; `undefined` removes it and forgets the rooms done. */
export function setThreadNotFoundHandler(handler) {
    threadNotFoundHandler = handler;
    threadsGone.clear();
}
/** The room id inside a 409 `Thread not found: <id>`, from the message (not from the body of the request); nothing for any other error. */
export function threadNotFoundId(error) {
    const failure = error;
    if (failure?.statusCode !== msg.HttpStatus.CONFLICT || typeof failure.message !== 'string')
        return undefined;
    return threadNotFoundIdInMessage(failure.message);
}
/** The same, from a message alone: for a caller that only has the text (the error was wrapped into a new `Error`). */
export function threadNotFoundIdInMessage(message) {
    return typeof message === 'string' ? THREAD_NOT_FOUND.exec(message)?.[1] : undefined;
}
/** Does not wait and does not repeat the request: the error goes up as it is. A failure of the handler is logged. */
function reportThreadNotFound(error) {
    const threadId = threadNotFoundId(error);
    if (!threadId || !threadNotFoundHandler || threadsGone.has(threadId))
        return;
    threadsGone.add(threadId);
    const handler = threadNotFoundHandler;
    void Promise.resolve()
        .then(() => handler(threadId))
        .catch((failure) => { console.error(`Could not drop the room ${threadId} the cm does not know`, failure); });
}
export async function post(args) {
    try {
        return await postOnce(args);
    }
    catch (error) {
        reportThreadNotFound(error);
        const sent = args.userId;
        if (!sent || !identityRefusedHandler || !isIdentityRefused(error))
            throw error;
        let newId;
        try {
            newId = await swapIdentity(sent);
        }
        catch {
            throw error;
        }
        if (!newId || newId === sent)
            throw error;
        // once: a second refusal goes up as it is
        return postOnce({ ...args, userId: newId });
    }
}
async function postOnce(args) {
    let urlHttp = environment.config.getApiUrl();
    try {
        const response = await fetch(urlHttp, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(args),
            credentials: environment.config.getApiCredentials()
        });
        if (response.status !== msg.HttpStatus.OK) {
            throw (await getPostError(response, args));
        }
        const data = await response.json();
        if (!data) {
            throw new Error("No data on cbePost");
        }
        return data;
    }
    catch (error) {
        console.info(error);
        throw error;
    }
}
export async function getPostError(response, args) {
    const data = await response.json()
        .catch(err => {
        console.error("Error on getPostError: ", err);
        return new Error(`No data on cbePost error: ${err}`);
    });
    const errorMsg = (typeof data.msg === 'string') ? data.msg : data.error || 'Unknown error';
    const makeError = (message) => {
        const error = new Error(message);
        error.statusCode = response.status;
        return error;
    };
    if (response.status === msg.HttpStatus.BAD_REQUEST) {
        console.error(`Error on cbePost, status: ${response.status}, msg: ${errorMsg}, invalid args: `, JSON.stringify(args));
        return makeError(`Invalid args, msg: ${errorMsg}`);
    }
    if (response.status === msg.HttpStatus.CONFLICT) {
        return makeError(`DomainError: ${errorMsg}`);
    }
    const msg2 = `Error on cbePost, status: ${response.status} - ${response.statusText}, error: ${errorMsg}`;
    console.error(msg2);
    return makeError(msg2);
}
export async function msgGetUsers(args) {
    return handleRequest(post({
        action: "getUsers",
        ...args
    }));
}
export function msgGetUserUpdate(args) {
    return handleRequest(post({
        action: "getUserUpdate",
        ...args
    }));
}
export function msgUpdateUserDetails(args) {
    return handleRequest(post({
        action: "updateUserDetails",
        ...args
    }));
}
export function msgAddThread(args) {
    return handleRequest(post({
        action: "addThread",
        ...args
    }));
}
export function msgUpdateThread(args) {
    return handleRequest(post({
        action: "updateThread",
        ...args
    }));
}
export function msgRemoveParticipantFromThread(args) {
    return handleRequest(post({
        action: "removeUserInThread",
        ...args
    }));
}
export function msgAddParticipantToThread(args) {
    return handleRequest(post({
        action: "addUserInThread",
        ...args
    }));
}
export function msgGetThreadUpdates(args) {
    return handleRequest(post({
        action: "getThreadUpdate",
        ...args
    }));
}
export function msgGetTaskUpdate(args) {
    return handleRequest(post({
        action: "getTaskUpdate",
        ...args
    }));
}
export function msgAddMessage(args) {
    return handleRequest(post({
        action: "addMessage",
        ...args
    }));
}
export function msgCreateAttachmentUpload(args) {
    return handleRequest(post({
        action: "createAttachmentUpload",
        ...args
    }));
}
export function msgCompleteAttachmentUpload(args) {
    return handleRequest(post({
        action: "completeAttachmentUpload",
        ...args
    }));
}
export function msgReportAttachmentUploadFailure(args) {
    return handleRequest(post({
        action: "reportAttachmentUploadFailure",
        ...args
    }));
}
export function msgDeleteAttachment(args) {
    return handleRequest(post({
        action: "deleteAttachment",
        ...args
    }));
}
export function msgGetAttachmentUrl(args) {
    return handleRequest(post({
        action: "getAttachmentUrl",
        ...args
    }));
}
export function msgEnsureTaskRoom(args) {
    return handleRequest(post({
        action: "ensureTaskRoom",
        ...args
    }));
}
export function msgAddMessageAI(args) {
    return handleRequest(post({
        action: "addMessageAI",
        ...args
    }));
}
export function msgAddOrUpdateThreadBot(args) {
    return handleRequest(post({
        action: "addOrUpdateThreadBot",
        ...args
    }));
}
export function msgAddOrUpdateThreadIntegration(args) {
    return handleRequest(post({
        action: "addOrUpdateThreadIntegration",
        ...args
    }));
}
export function msgGetMessagesAfter(args) {
    return handleRequest(post({
        action: "getMessagesAfter",
        ...args
    }));
}
export function msgGetMessagesBefore(args) {
    return handleRequest(post({
        action: "getMessagesBefore",
        ...args
    }));
}
export function msgGetMessage(args) {
    return handleRequest(post({
        action: "getMessage",
        ...args
    }));
}
export function msgUpdateMessage(args) {
    return handleRequest(post({
        action: "updateMessage",
        ...args
    }));
}
export function msgAddOrUpdateOpenClawConnector(args) {
    return handleRequest(post({
        action: "addOrUpdateOpenClawConnector",
        ...args
    }));
}
export function msgRemoveOpenClawConnector(args) {
    return handleRequest(post({
        action: "removeOpenClawConnector",
        ...args
    }));
}
export function msgListOpenClawConnectors(args) {
    return handleRequest(post({
        action: "listOpenClawConnectors",
        ...args
    }));
}
export function msgListOpenClawConnectorAgents(args) {
    return handleRequest(post({
        action: "listOpenClawConnectors",
        ...args
    }));
}
export function msgListThreadOpenClawAgents(args) {
    return handleRequest(post({
        action: "listThreadOpenClawAgents",
        ...args
    }));
}
export function msgAddOrUpdateThreadOpenClawAgent(args) {
    return handleRequest(post({
        action: "addOrUpdateThreadOpenClawAgent",
        ...args
    }));
}
export function msgRemoveThreadOpenClawAgent(args) {
    return handleRequest(post({
        action: "removeThreadOpenClawAgent",
        ...args
    }));
}
export function msgCreateOpenClawAgent(args) {
    return handleRequest(post({
        action: "createOpenClawAgent",
        ...args
    }));
}
export function msgDeleteOpenClawAgent(args) {
    return handleRequest(post({
        action: "deleteOpenClawAgent",
        ...args
    }));
}
export function msgListOpenClawAvailableAgents(args) {
    return handleRequest(post({
        action: "listOpenClawAvailableAgents",
        ...args
    }));
}
// ── Agent-orchestration helpers (raw: resolve to the response, throw on non-2xx)
// Used cross-project by 102027/102020/100554. Kept raw to match the contract
// those call sites already rely on. Single client — routes via getApiUrl (102036).
export function msgApplyIntents(args) {
    return post({ action: "applyIntents", ...args });
}
export function msgAppendLongTermMemory(args) {
    return post({ action: "appendLongTermMemory", ...args });
}
