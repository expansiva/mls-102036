/// <mls fileReference="_102036_/l2/environmentContract.ts" enhancement="_blank"/>
/**
 * DEFAULTS (fallback)
 */
const defaultNotifications = {
    getFCMTokenForBackend: () => Promise.resolve(null),
    getNotifySoundUrl: () => Promise.resolve(null),
    sendRequestMissed: () => Promise.resolve(),
    sendACK: () => Promise.resolve(),
};
const defaultBots = {
    getArgsToBots: () => Promise.resolve({}),
    getBotContextVarsBeforeMessageSend: () => Promise.resolve([]),
    getBotContextVarsBeforeMessageSend2: () => Promise.resolve([]),
};
const defaultAgents = {
    generateSvgAvatar: () => Promise.resolve(null),
    executeAgent: () => Promise.resolve(),
    loadAgent: () => Promise.resolve(null),
};
const defaultTasks = {
    openTaskDetails: async (_messageId, _taskId, task, message) => {
        const element = document.createElement('collab-messages-task-info-102025');
        element.task = task;
        element.message = message;
        return { openLocal: true, element };
    },
};
const defaultApps = {
    getProgramMenu: () => Promise.resolve([]),
    openProgram: () => Promise.resolve(),
};
const defaultConfig = {
    getMenuMode: () => 'default',
    generateSvgAvatarEnabled: () => false,
    getApiUrl: () => 'https://on.collab.codes/exec',
    getApiCredentials: () => 'include',
    getDefaultUserName: () => 'User',
};
/**
 * ENV GLOBAL
 */
let _envCollabMessages = null;
export function setEnvironment(env) {
    _envCollabMessages = env;
}
function getEnv() {
    return _envCollabMessages ?? {};
}
/**
 * NORMALIZERS
 */
function getEnvNotifications() {
    return {
        ...defaultNotifications,
        ...getEnv().notifications,
    };
}
function getEnvBots() {
    return {
        ...defaultBots,
        ...getEnv().bots,
    };
}
function getEnvAgents() {
    return {
        ...defaultAgents,
        ...getEnv().agents,
    };
}
function getEnvTasks() {
    return {
        ...defaultTasks,
        ...getEnv().tasks,
    };
}
function getEnvApps() {
    return {
        ...defaultApps,
        ...getEnv().apps,
    };
}
function getEnvConfig() {
    return {
        ...defaultConfig,
        ...getEnv().config,
    };
}
/**
 * FACADE FINAL
 */
export const environment = {
    getAgents: () => getEnv().getAgents?.() ?? Promise.resolve([]),
    getIntegrationsOpenClaw: () => getEnv().getIntegrationsOpenClaw?.() ?? Promise.resolve([]),
    setIntegrationsOpenClaw: (integrations) => getEnv().setIntegrationsOpenClaw?.(integrations) ?? Promise.resolve(),
    notifications: {
        getFCMTokenForBackend: () => getEnvNotifications().getFCMTokenForBackend(),
        getNotifySoundUrl: () => getEnvNotifications().getNotifySoundUrl(),
        sendRequestMissed: () => getEnvNotifications().sendRequestMissed(),
        sendACK: (id) => getEnvNotifications().sendACK(id),
    },
    bots: {
        getArgsToBots: () => getEnvBots().getArgsToBots(),
        getBotContextVarsBeforeMessageSend: (thread, messageText) => getEnvBots().getBotContextVarsBeforeMessageSend(thread, messageText),
        getBotContextVarsBeforeMessageSend2: (vars, myArgs) => getEnvBots().getBotContextVarsBeforeMessageSend2(vars, myArgs),
    },
    agents: {
        generateSvgAvatar: (threadId, userId, promptToAvatar) => getEnvAgents().generateSvgAvatar(threadId, userId, promptToAvatar),
        executeAgent: (agentToCall, context) => getEnvAgents().executeAgent(agentToCall, context),
        loadAgent: (agentName) => getEnvAgents().loadAgent(agentName),
    },
    tasks: {
        openTaskDetails: (messageId, taskId, task, message) => getEnvTasks().openTaskDetails(messageId, taskId, task, message)
    },
    apps: {
        getProgramMenu: () => getEnvApps().getProgramMenu(),
        openProgram: (item) => getEnvApps().openProgram(item),
    },
    config: {
        getMenuMode: () => getEnvConfig().getMenuMode(),
        generateSvgAvatarEnabled: () => getEnvConfig().generateSvgAvatarEnabled(),
        getApiUrl: () => getEnvConfig().getApiUrl(),
        getApiCredentials: () => getEnvConfig().getApiCredentials(),
        getDefaultUserName: () => getEnvConfig().getDefaultUserName()
    }
};
